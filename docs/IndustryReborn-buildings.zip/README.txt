Здания IndustryReborn (формат .ir.json). Положите файлы в plugins/IndustryReborn/buildings/.
Здания нарисованы генератором scripts/gen-buildings.py; лицензия та же, что у плагина.
